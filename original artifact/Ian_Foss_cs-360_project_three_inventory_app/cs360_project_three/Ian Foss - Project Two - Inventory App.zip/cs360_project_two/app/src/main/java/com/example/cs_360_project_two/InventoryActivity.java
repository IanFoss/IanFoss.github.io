package com.example.cs_360_project_two;

import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.ipsec.ike.exceptions.InvalidMajorVersionException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.cs_360_project_two.InventoryItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        // Test data for the recyclerview which will later come from database
        ArrayList<InventoryItem> itemList = new ArrayList<>();
        itemList.add(new InventoryItem("Hammer", "1", 4));
        itemList.add(new InventoryItem("Pipe Wrench", "2", 6));
        itemList.add(new InventoryItem("Chainsaw", "3", 2));


        // Instantiates recyclerview, adds divider, sets it's layoutmanager and adapter
        RecyclerView recyclerView = findViewById(R.id.inventory_recycler_view);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new InventoryAdapter(this, itemList));


        // Floating action button to add item to inventory
        FloatingActionButton fab = findViewById(R.id.add_item_fab);
        fab.setImageTintList(ColorStateList.valueOf(Color.WHITE));
        fab.setOnClickListener(v -> {

            // Inflates dialog layout when button it pressed
            LayoutInflater inflater = LayoutInflater.from(this);
            View dialogView = inflater.inflate(R.layout.dialog_add_item, null);

            EditText nameInput = dialogView.findViewById(R.id.edit_name);
            EditText quantityInput = dialogView.findViewById(R.id.edit_quantity);
            EditText locationInput = dialogView.findViewById(R.id.edit_location);

            // Dialog displays fields for item name, quantity, and location (ID would ideally be auto generated)
            // Ensures quantity is an integer
            new AlertDialog.Builder(this)
                    .setTitle("Add Inventory Item")
                    .setView(dialogView)
                    .setPositiveButton("Add", ((dialog, which) -> {
                        String name = nameInput.getText().toString();
                        String quantityString = quantityInput.getText().toString();
                        String location = locationInput.getText().toString();

                        int quantity = 0;

                        try {
                            quantity = Integer.parseInt(quantityString);
                        } catch (NumberFormatException e) {
                            Toast.makeText(this, "Invalid Quantity", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }))
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }
}