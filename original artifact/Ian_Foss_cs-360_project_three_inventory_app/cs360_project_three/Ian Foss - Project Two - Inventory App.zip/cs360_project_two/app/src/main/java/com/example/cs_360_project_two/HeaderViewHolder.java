package com.example.cs_360_project_two;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class HeaderViewHolder extends RecyclerView.ViewHolder {

    public HeaderViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
