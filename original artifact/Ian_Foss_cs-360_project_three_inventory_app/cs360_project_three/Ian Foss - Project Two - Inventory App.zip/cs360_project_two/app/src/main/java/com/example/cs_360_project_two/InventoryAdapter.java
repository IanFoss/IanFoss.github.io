package com.example.cs_360_project_two;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs_360_project_two.InventoryViewHolder;
import com.example.cs_360_project_two.HeaderViewHolder;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private static final int VIEW_TYPE_HEADER = 0;
    private static final int VIEW_TYPE_ITEM = 1;
    private List<InventoryItem> itemList;
    private Context context;

    public InventoryAdapter(Context context, List<InventoryItem> itemList) {
        this.itemList = itemList;
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        return (position == 0 ) ? VIEW_TYPE_HEADER : VIEW_TYPE_ITEM;
    }


    // Inflates views for recyclerview header row and item rows
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        if (viewType == VIEW_TYPE_HEADER) {
            View view = inflater.inflate(R.layout.recyclerview_header_row, parent, false);
            return new HeaderViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.recyclerview_inventory_row, parent, false);
            return new InventoryViewHolder(view);
        }
    }


    // Binds InventoryItem data to the viewholders
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

         // Ensure the header row does not get the data
         if (getItemViewType(position) == VIEW_TYPE_ITEM) {
             int dataPosition = position - 1;
             InventoryItem item = itemList.get(dataPosition);
             ((InventoryViewHolder) holder).bind(item, () -> {
                 itemList.remove(dataPosition);
                 notifyItemRemoved(position);
                 notifyItemRangeChanged(position, getItemCount());
             });
        }
    }


    @Override
    public int getItemCount() {
        return itemList.size() + 1 ;
    }







}
